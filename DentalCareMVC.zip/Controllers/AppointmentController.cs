using System;
using System.Web.Mvc;
namespace DentalCare.Controllers
{
    public class AppointmentController : Controller
    {
        public ActionResult Book() => View();
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Submit(string name, string email, string phone, DateTime date, string service, string message)
        {
            try { TempData["Success"] = "✅ Your appointment has been booked!"; }
            catch (Exception ex) { TempData["Error"] = "❌ Failed to book appointment."; }
            return RedirectToAction("Index", "Home");
        }
    }
}