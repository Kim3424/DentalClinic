using System;
using System.Web.Mvc;
namespace DentalCare.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index() => View();
        public ActionResult About() => View();
        public ActionResult Services() => View();
        public ActionResult Departments() => View();
        public ActionResult Doctors() => View();
        public ActionResult Contact() => View();
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SendMessage(string name, string email, string subject, string message)
        {
            try { TempData["Success"] = "✅ Your message has been sent successfully!"; }
            catch (Exception ex) { TempData["Error"] = "❌ Failed to send message."; }
            return RedirectToAction("Contact");
        }
    }
}